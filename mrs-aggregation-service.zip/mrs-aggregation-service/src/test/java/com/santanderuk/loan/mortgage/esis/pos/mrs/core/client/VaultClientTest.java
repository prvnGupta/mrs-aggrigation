package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;


import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.ApplicationHelperConfig;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception.CoreServiceErrorHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.http.HttpStatus.GONE;
import static org.springframework.http.HttpStatus.MOVED_PERMANENTLY;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.converter.json.Jackson2ObjectMapperBuilder.json;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withNoContent;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

@RestClientTest(VaultClient.class)
@Import({ApplicationHelperConfig.class, AppProps.class, CoreServiceErrorHandler.class, EsisCoreEngineClient.class})
class VaultClientTest {
    private final String outgoingPath = "src/test/resources/json-files/esis/%s.json";

    private MockRestServiceServer server;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private VaultClient service;

    @BeforeEach
    void setUp() {
        server = MockRestServiceServer.createServer(restTemplate);
    }

    @Test
    @DisplayName("retrieveVaultDocument - Successful Response")
    void shouldSendCorrectRequest() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost:8089/vault/document/retrieveByReference"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().json("{\"uid\":\"ABC123\"}"))
                .andRespond(withSuccess(getJsonFromFile(String.format(outgoingPath, "vault-retrieve-response")), APPLICATION_JSON));
        service.retrieveVaultDocument("ABC123");
        server.verify();
    }

    @Test
    @DisplayName("retrieveVaultDocument - Error Response")
    void shouldSendFailureRequest() throws Exception {
        String responseString = getJsonFromFile(String.format(outgoingPath, "vault-retrieve-response"));
        server.expect(ExpectedCount.once(), requestTo("http://localhost:8089/vault/document/retrieveByReference"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().json("{\"uid\":\"ABC123\"}"))
                .andRespond(withServerError().body(responseString));
        assertThatThrownBy(() -> service.retrieveVaultDocument("ABC123"))
                .isInstanceOf(CoreServiceException.class);
    }

    @Test
    @DisplayName("retrieveVaultDocument - 3xxRedirection Response")
    void shouldSendFailureRequestAfterRedirectionResponse() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost:8089/vault/document/retrieveByReference"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().json("{\"uid\":\"ABC123\"}"))
                .andRespond(withStatus(MOVED_PERMANENTLY));
        assertThatThrownBy(() -> service.retrieveVaultDocument("ABC123"))
                .isInstanceOf(CoreServiceException.class);
    }

    @Test
    @DisplayName("retrieveVaultDocument - Not Found Response")
    void shouldSendFailureRequestAfterNotFoundResponse() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost:8089/vault/document/retrieveByReference"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().json("{\"uid\":\"ABC123\"}"))
                .andRespond(withStatus(NOT_FOUND));

        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withSuccess());

        service.retrieveVaultDocument("ABC123");
        server.verify();
    }

    @Test
    @DisplayName("retrieveVaultDocument - Error RestClientException")
    void shouldSendFailureRequestAfterClientException() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost:8089/vault/document/retrieveByReference"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().json("{\"uid\":\"ABC123\"}"))
                .andRespond((response) -> {
                    throw new RestClientException(
                            "Connection reset");
                });
        service.retrieveVaultDocument("ABC123");
        server.verify();
    }

    @Test
    @DisplayName("retrieveVaultDocument - Gone Response")
    void shouldSendFailureRequestAfterGoneResponse() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost:8089/vault/document/retrieveByReference"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().json("{\"uid\":\"ABC123\"}"))
                .andRespond(withStatus(GONE));

        assertThatThrownBy(() -> service.retrieveVaultDocument("ABC123"))
                .isInstanceOf(CoreServiceException.class);
    }

    public static String getJsonFromFile(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)));
    }
}