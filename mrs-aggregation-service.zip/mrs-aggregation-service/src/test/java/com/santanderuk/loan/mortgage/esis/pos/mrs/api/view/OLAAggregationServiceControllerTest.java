package com.santanderuk.loan.mortgage.esis.pos.mrs.api.view;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.nio.file.Files;
import java.nio.file.Paths;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.APPLICATION_XML;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class OLAAggregationServiceControllerTest extends AbstractControllerIntegrationTest {

    private static String ESIS_ENDPOINT = "/document/%s";
    private static String ESIS_DOC = "/posdocuments";
    private static String authToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludHJhbmV0Q2xpZW50X1JTMjU2IiwidmVyIjoiMS4yLjA6c2FudWsifQ.eyJpc3MiOiJJbnRyYW5ldENsaWVudCIsInN1YiI6ImFiMDEyMzkzIiwiYXVkIjoiYW5tZiIsIm5iZiI6MTU1Nzc0ODM0MiwiZXhwIjoxNTU3NzQ4NDYyLCJpYXQiOjE1NTc3NDgzNDIsImp0aSI6ImE0NTI4ZDE1LTBiYzAtNGQxOC04MjM5LWJlNzJiNDFjOWVjOSIsIm1pcyI6ImE6MEEzNDAwMzQ2ODRCMkY4QkIwODVEOTY3Ojo6OkFiYmV5SW50cmFuZXRQUkU6RTEwNjEwMDEiLCJlbnQiOiJyZXRhaWwiLCJlbnYiOiJpbnRyYW5ldCJ9.cHikOiRAfa9tRGxFJbW60U82d50zVHLkxtN8H5sfj1GBsl4LLlJ4cMCy2rjDpV4vstaUuvjNNacTIEObD4zuIDXvhttWnPX4b2LH8bC6BHp-Jixr1DKtpmCPdbBMad2mwNK3BkrzNWAoJ1HuB14GEmJFq3dxKHgJfRCA-5ZObV_h2dI98-79kMe8qSd7MIshawjKjSibjkBszg0brUJVEspSigxO8VIS0XQjb3Zvabk26pGngf-3im1Xyf-kYp7GOaouGDYSZP-o7llmySrjxFih5Yd8gpROJbJFAL4QzsTczyD1GNBn6FIWV6ITee5s1LGVj8e9_l7DZQHFSxpi6w";
    private static String kfiId = "5A897BF8A9F0451C960CA0916178EAA0";


    @Test
    public void shouldReturnEsisAsPDF() throws Exception {
        this.setupVault(200);
        mvc.perform(MockMvcRequestBuilders.get(String.format(ESIS_ENDPOINT, kfiId))
                .header(AUTHORIZATION, this.authToken))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldPopulateEsisDocument() throws Exception {
        this.setupEsisDoc("kfi-response.json", 200);
        this.setupGenDoc("ok.json", 200);
        this.setupVaultIngest(200);
        String body = new String(Files.readAllBytes(
                Paths.get("src/test/resources/testRequest/1_KFIengine_request.xml")));
        mvc.perform(MockMvcRequestBuilders.post(ESIS_DOC)
                .content(body)
                .header(CONTENT_TYPE, APPLICATION_XML)
                .header(AUTHORIZATION, this.authToken))
                .andExpect(status().isCreated());
    }

}
