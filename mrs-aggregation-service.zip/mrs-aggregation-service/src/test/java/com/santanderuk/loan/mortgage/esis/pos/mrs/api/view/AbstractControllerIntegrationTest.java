package com.santanderuk.loan.mortgage.esis.pos.mrs.api.view;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.common.Slf4jNotifier;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = RANDOM_PORT)
@AutoConfigureMockMvc
public abstract class AbstractControllerIntegrationTest {

    @Autowired
    protected MockMvc mvc;

    @Value("${test.wiremock.port}")
    private Integer wiremockPort;

    @Value("${test.wiremock.verbose:false}")
    private Boolean verbose;

    protected WireMockServer server;

    @BeforeEach
    public void setUp() throws Exception {
        server = new WireMockServer(options()
                .port(wiremockPort)
                .notifier(new Slf4jNotifier(verbose)));
        server.start();
        configureFor("localhost", wiremockPort);
    }

    @AfterEach
    public void tearDown() {
        server.stop();
    }

    public void setupVault(int expectedHttpStatus) throws IOException {
      final String outgoingPath = "src/test/resources/json-files/esis/%s.json";

        stubFor(post(urlEqualTo("/vault/document/retrieveByReference"))
                .willReturn(aResponse()
                        .withStatus(expectedHttpStatus)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                        .withBody(getJsonFromFile(String.format(outgoingPath, "vault-retrieve-response")))));
    }

    public void setupEsisDoc(String filename, int expectedHttpStatus) throws IOException {
        String fileNameData =
                new String(Files.readAllBytes(
                        Paths.get("src/test/resources/json-files/" + filename)));

        stubFor(post(urlEqualTo("/mortgage-sale-agreement/v2/esis-document"))
                .willReturn(aResponse()
                        .withStatus(expectedHttpStatus)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                        .withBody(fileNameData)));


    }

    public void setupGenDoc(String filename, int expectedHttpStatus) throws IOException {
        String fileNameData =
                new String(Files.readAllBytes(
                        Paths.get("src/test/resources/json-files/gen-doc/" + filename)));

        stubFor(post(urlEqualTo("/doc-mgt-arch/cresp-services/v1/gen-doc-base64"))
                .willReturn(aResponse()
                        .withStatus(expectedHttpStatus)
                        .withHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                        .withBody(fileNameData)));
    }

    protected void setupVaultIngest(int expectedHttpStatus){
        stubFor(post(urlPathEqualTo("/nuxeoServices/ingestDocument"))
                .willReturn(aResponse()
                        .withStatus(expectedHttpStatus)));
    }

    public static String getJsonFromFile(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)));
    }
}
