package com.santanderuk.loan.mortgage.esis.pos.mrs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by C0251500 on 13/03/2018
 * Description :
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MRSAggregationServiceApplicationTest.class)
//@TestPropertySource(locations="classpath:test-properties.yml")
public class MRSAggregationServiceApplicationTest {

    @Test
    public void contextLoads() throws Exception
    {

    }

}