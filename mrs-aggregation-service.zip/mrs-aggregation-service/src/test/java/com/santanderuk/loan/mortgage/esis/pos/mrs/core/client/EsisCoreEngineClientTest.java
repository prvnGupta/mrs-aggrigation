package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception.ResourceNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.client.response.MockRestResponseCreators;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.SYSTEM_ERROR;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName.ESIS_CORE_ENGINE_SERVICE;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Paths;

import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

//@RestClientTest(EsisCoreEngineClient.class)
//@Import({ApplicationHelperConfig.class, AppProps.class, CoreServiceErrorHandler.class})
@SpringBootTest
@ExtendWith(SpringExtension.class)
class EsisCoreEngineClientTest {

    private final String outgoingPath = "src/test/resources/json-files/esis-core/%s";

    private MockRestServiceServer server;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private EsisCoreEngineClient service;

    @BeforeEach
    void setUp() {
        server = MockRestServiceServer.createServer(restTemplate);
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - Successful Response")
    void shouldSendCorrectRequest() throws Exception {
        String responseString = getJsonFromFile(String.format(outgoingPath, "successAbbeyN.xml"));
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(MockRestResponseCreators.withSuccess(responseString, MediaType.APPLICATION_XML));
        service.retrieveKfiAsPdf("ABC123");
        server.verify();
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - Error Abbey Y")
    void shouldSendFailureRequestAbbeyY() throws Exception {
        String responseString = getJsonFromFile(String.format(outgoingPath, "successAbbeyY.xml"));
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(MockRestResponseCreators.withSuccess(responseString, MediaType.APPLICATION_XML));
        assertThatThrownBy(() -> service.retrieveKfiAsPdf("ABC123"))
                .isInstanceOf(CoreServiceException.class);
        server.verify();
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - JAXBException")
    void shouldSendFailureRequestJAXBException() throws Exception {
        String responseString = getJsonFromFile(String.format(outgoingPath, "JAXBError.xml"));
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(MockRestResponseCreators.withSuccess(responseString, MediaType.APPLICATION_XML));
        assertThatThrownBy(() -> service.retrieveKfiAsPdf("ABC123"))
                .isInstanceOf(CoreServiceException.class);
        server.verify();
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - Error Response")
    void shouldSendFailureRequest() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withServerError());
        assertThatThrownBy(() -> service.retrieveKfiAsPdf("ABC123"))
                .isInstanceOf(CoreServiceException.class);
        server.verify();
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - Error ServiceCallFailureException")
    void shouldSendServiceCallFailureException() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond((response) -> { throw new ResourceAccessException(
                        "Connection reset"); });
        assertThatThrownBy(() -> service.retrieveKfiAsPdf("ABC123"))
                .isInstanceOf(CoreServiceException.class);
        server.verify();
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - UNAUTHORIZED Response")
    void shouldSendFailureRequestAfterUnauthorisedResponse() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(UNAUTHORIZED));

        assertThatThrownBy(() -> service.retrieveKfiAsPdf("ABC123"))
                .isInstanceOf(CoreServiceException.class);
        server.verify();
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - Not Found Response")
    void shouldSendFailureRequestAfterNotFoundResponse() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(NOT_FOUND));

        assertThatThrownBy(() -> service.retrieveKfiAsPdf("ABC123"))
                .isInstanceOf(CoreServiceException.class);
        server.verify();
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - Error ServiceCallFailureException Long")
    void shouldSendFailureRequestAfterNotFoundResponseLong() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond((response) -> {
                    try {
                        throw new ResourceNotFoundException(ESIS_CORE_ENGINE_SERVICE, SYSTEM_ERROR,
                                "Connection reset", new Throwable());
                    } catch (ResourceNotFoundException e) {
                        e.printStackTrace();
                    }
                    return null;
                });
        assertThatThrownBy(() -> service.retrieveKfiAsPdf("ABC123"))
                .isInstanceOf(NullPointerException.class);
        server.verify();
    }

    @Test
    @DisplayName("retrieveKfiAsPdf - Error CoreServiceException")
    void shouldSendFailureRequestAfterCoreServiceException() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost/mortgage-sale-agreement/v2/retrieve-kfi-data/ABC123"))
                .andExpect(method(HttpMethod.GET))
                .andRespond((response) -> {
                    try {
                        throw new CoreServiceException(
                                ESIS_CORE_ENGINE_SERVICE, SYSTEM_ERROR);
                    } catch (CoreServiceException e) {
                        e.printStackTrace();
                    }
                    return null;
                });
        assertThatThrownBy(() -> service.retrieveKfiAsPdf("ABC123"))
                .isInstanceOf(NullPointerException.class);
        server.verify();
    }

    public static String getJsonFromFile(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)));
    }

}