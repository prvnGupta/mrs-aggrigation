package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.ApplicationHelperConfig;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception.CoreServiceErrorHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedHashMap;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

@RestClientTest(GmcClient.class)
@Import({ApplicationHelperConfig.class, AppProps.class, CoreServiceErrorHandler.class, EsisCoreEngineClient.class})
class GmcClientTest {
    private final String outgoingPath = "src/test/resources/json-files/gen-doc/%s.json";

    private MockRestServiceServer server;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private GmcClient service;

    @BeforeEach
    void setUp() {
        server = MockRestServiceServer.createServer(restTemplate);
    }

    @Test
    @DisplayName("generateTemplateAsPDF - Successful Response")
    void shouldSendCorrectRequest() throws Exception {
        server.expect(ExpectedCount.once(), requestTo("http://localhost:8089/doc-mgt-arch/cresp-services/v1/gen-doc-base64"))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withSuccess(getJsonFromFile(String.format(outgoingPath, "ok")), APPLICATION_JSON));
        service.generateTemplateAsPDF(getRequest());
        server.verify();
    }

    @Test
    @DisplayName("generateTemplateAsPDF - Error Response")
    void shouldSendFailureRequest() throws Exception {
        String responseString = getJsonFromFile(String.format(outgoingPath, "ok"));
        server.expect(ExpectedCount.once(), requestTo("http://localhost:8089/doc-mgt-arch/cresp-services/v1/gen-doc-base64"))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withServerError().body(responseString));
        assertThatThrownBy(() -> service.generateTemplateAsPDF(getRequest()))
                .isInstanceOf(CoreServiceException.class);
    }

    @Test
    @DisplayName("generateTemplateAsPDF - not LinkedHash")
    void shouldNotSendWhenNotHash() throws Exception {
        assertThatThrownBy(() -> service.generateTemplateAsPDF("Hello"))
                .isInstanceOf(CoreServiceException.class);
    }

    public static String getJsonFromFile(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)));
    }

    private LinkedHashMap<Object, Object> getRequest() {
        LinkedHashMap<Object, Object> request = new LinkedHashMap<>();
        LinkedHashMap<Object, Object> documentData = new LinkedHashMap<>();
        documentData.put("QuotationReferenceNumber", "theREfNumber");
        request.put("DocumentData", documentData);
        return request;
    }

}
