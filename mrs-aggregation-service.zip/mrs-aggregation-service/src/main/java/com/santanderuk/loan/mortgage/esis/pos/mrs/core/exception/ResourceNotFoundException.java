package com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception;

import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName;

public class ResourceNotFoundException extends CoreServiceException {

    public ResourceNotFoundException(ServiceName serviceName, ErrorType erroType, String message) {
        super(serviceName, erroType, message);
    }

    public ResourceNotFoundException(ServiceName serviceName, ErrorType erroType, String message, Throwable cause) {
        super(serviceName, erroType, message, cause);
    }
}
