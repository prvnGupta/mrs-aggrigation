package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_ESIS_CORE_ENGINE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_GMC_API;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName.ESIS_CORE_ENGINE_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName.GMC_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.EMPTY_STRING;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.ESIS_DOCUMENT_DATA;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.QUOTATION_REFERENCE_NUMBER;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.X_IBM_CLIENT_ID;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_CORE_RESPONSE_BAD_FORMAT;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_GMC_BAD_RESPONSE;

import java.util.LinkedHashMap;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.GMCRequestBean;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.GMCResponseBean;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception.CoreServiceErrorHandler;

/**
 * Created by C0251500 on 20/03/2017 Description :
 */
@Component
public class GmcClient extends BaseClient {

	private static final Logger LOG = LoggerFactory.getLogger(GmcClient.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private AppProps appProps;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private CoreServiceErrorHandler coreServiceErrorHandler;

	private String gmcCoreServiceURIBase64;
	private String gmcClientID;
	private String gmcTemplate;
	private String gmcDocumentCode;

	public Response generateTemplateAsPDF(Object esisResponse) throws CoreServiceException {
		LOG.info("Start - generateTemplateAsPDF...");
		String gmcResponse = null;
		String esisReference = null;
		try {
			if (esisResponse instanceof LinkedHashMap) {
				esisReference = (String) ((LinkedHashMap<?, ?>) ((LinkedHashMap<?, ?>) esisResponse).get(ESIS_DOCUMENT_DATA))
						.get(QUOTATION_REFERENCE_NUMBER);
				LOG.debug("ESIS Reference to generate ESIS pdf :- {}", esisReference);
			} else {
				CoreServiceException coreServiceException = new CoreServiceException(ESIS_CORE_ENGINE_SERVICE,
						ERROR_ESIS_CORE_ENGINE, ERR_CORE_RESPONSE_BAD_FORMAT);
				LOG.error("ESIS response parsing error : ServiceName : {} - Message : {} ",
						coreServiceException.getServiceName(), coreServiceException.getMessage());
				throw coreServiceException;
			}
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(X_IBM_CLIENT_ID, gmcClientID);
			HttpEntity<Object> entity = new HttpEntity<>(populateGMCBean(esisResponse), headers);

			LOG.info("Start - GMC service call");
			ResponseEntity<GMCResponseBean> jsonResponse = restTemplate.postForEntity(gmcCoreServiceURIBase64, entity,
					GMCResponseBean.class);
      GMCResponseBean gmcResponseBean = jsonResponse.getBody();
			if (null == gmcResponseBean) {
				CoreServiceException coreServiceException = new CoreServiceException(GMC_SERVICE, ERROR_GMC_API,
						ERR_GMC_BAD_RESPONSE);
				LOG.error("CCM response error - No response from CCM service");
				throw coreServiceException;
			}
			LOG.info("Done - GMC service call");
			gmcResponse = gmcResponseBean.getPayload();

			LOG.info("Done - generateTemplateAsPDF...");

		} catch (RestClientException restClientException) {
			LOG.error("RESTClient error: Generating ESIS pdf - Reference ID : {}", esisReference);
			LOG.error("RESTClient error: Generating ESIS pdf - StackTrace : ", restClientException);
			coreServiceErrorHandler.handleRestClientException(restClientException, GMC_SERVICE, ERROR_GMC_API);
		}
		LOG.info("Done - generateTemplateAsPDF...");

		return populateResponseBean(esisReference, gmcResponse);
	}

	private String populateGMCBean(Object object) throws CoreServiceException {
		LOG.debug("Start - populateGMCBean...");
		String gmcRequest = EMPTY_STRING;
		GMCRequestBean gmcRequestBean = new GMCRequestBean();
		gmcRequestBean.setDocumentCode(gmcDocumentCode);
		gmcRequestBean.setTemplate(gmcTemplate);
		gmcRequestBean.setVariables(object);
		try {
			gmcRequest = objectMapper.writeValueAsString(gmcRequestBean);
		} catch (JsonProcessingException e) {
			CoreServiceException coreServiceException = new CoreServiceException(GMC_SERVICE, ERROR_GMC_API,
					ERR_GMC_BAD_RESPONSE);
			LOG.error("Json ParseException : ", e);
			throw coreServiceException;
		}
		LOG.debug("Done - populateGMCBean...");
		return gmcRequest;
	}

	@PostConstruct
	private void constructResourceUri() {
		gmcCoreServiceURIBase64 = appProps.getGmcCoreServiceURIBase64();
		gmcClientID = appProps.getGmcClientId();
		gmcTemplate = appProps.getGmcTemplate();
		gmcDocumentCode = appProps.getGmcDocumentCode();

		LOG.debug("URL: gmcCoreServiceURIBase64:= {}", gmcCoreServiceURIBase64);
		LOG.debug("URL: gmcTemplate:= {}", gmcTemplate);
		LOG.debug("URL: gmcDocumentCode:= {}", gmcDocumentCode);
	}

}
