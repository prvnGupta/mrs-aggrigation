package com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorResponse;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName;

@Component
public class CoreServiceErrorHandler {

    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CoreServiceErrorHandler.class);
    private static final String URL_OPEN_ERROR = "500 URL Open Error";
    private static final JAXBContext context;

    static {
        try {
            context = JAXBContext.newInstance(ErrorResponse.class);
        } catch (JAXBException error) {
            LOG.error("JAXBException : ", error);
            throw new RuntimeException(error);
        }
    }

    @Autowired
    private ObjectMapper objectMapper;

    // todo refactor method for proper simple handling
    private void handleRestClientResponseException(RestClientResponseException responseException,
                                                   ServiceName serviceName, ErrorType errorType) throws CoreServiceException {
        ErrorResponse errorResponse = null;
        String responseBodyAsString = responseException.getResponseBodyAsString();
        int rawCode = responseException.getRawStatusCode();
        String localMsg = responseException.getLocalizedMessage();

        if (rawCode == HttpStatus.NOT_FOUND.value()) {
            LOG.error("A RestClientResponseException : {} : {} ", rawCode, responseBodyAsString);
            throw new ResourceNotFoundException(serviceName, errorType, responseException.getMessage());
        } else if (rawCode == HttpStatus.UNAUTHORIZED.value()) {
            LOG.error("B RestClientResponseException : {} : {}", rawCode, responseBodyAsString);
            throw new CoreServiceException(serviceName, errorType, responseBodyAsString);
        } else if (rawCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
            LOG.error("C RestClientResponseException : StatusCode : {}", rawCode);

            if (localMsg != null && localMsg.equalsIgnoreCase(URL_OPEN_ERROR)) {
                responseBodyAsString = URL_OPEN_ERROR;
            }

            LOG.error("C RestClientResponseException : ResponseMessage : {}", responseBodyAsString);
            LOG.error("C RestClientResponseException : Local Message : {}", localMsg);
            throw new CoreServiceException(serviceName, errorType, localMsg);
        } else {
            checkResponse(serviceName, errorType, responseBodyAsString);
        }
    }

    private void checkResponse(ServiceName serviceName, ErrorType errorType, String responseBodyAsString) throws CoreServiceException {
        ErrorResponse errorResponse;
        try {
            errorResponse = objectMapper.readValue(responseBodyAsString, ErrorResponse.class);
            LOG.error("RestClientResponseException : {} :  {}", errorResponse.getError(),
                    errorResponse.getMoreInformation());
        } catch (JsonParseException jsonError) {
            LOG.error("RestClientResponseException - JsonParseException : {} : {}", jsonError.getMessage(),
                    jsonError.getRequestPayloadAsString());
            try {
                InputStream stream = new ByteArrayInputStream(responseBodyAsString.getBytes(StandardCharsets.UTF_8));
                errorResponse = (ErrorResponse) context.createUnmarshaller().unmarshal(stream);
            } catch (JAXBException error) {
                LOG.error("JAXBException : ", error);
                throw new CoreServiceException(serviceName, errorType,
                        "Client communication error: Unable to generate error response due to internal server error");
            }
            if (errorResponse != null && errorResponse.getDescription() != null) {
                LOG.error("JsonParseException : {} : {}", errorResponse.getError(),
                        errorResponse.getMoreInformation());
                throw new CoreServiceException(serviceName, errorType, errorResponse.getDescription());
            } else {
                LOG.error("JsonParseException : Error response is null or empty");
                throw new CoreServiceException(serviceName, errorType,
                        "Description not available as error response is null");
            }
        } catch (IOException ioError) {
            LOG.error("IOException : Stacktrace : ", ioError);
            throw new CoreServiceException(serviceName, errorType, ioError.getMessage());
        }
        LOG.error("D RestClientResponseException : {} : {}", errorResponse.getDescription(),
                errorResponse.getMoreInformation());

        if (errorResponse.getError() != null
                && errorResponse.getError().equalsIgnoreCase(ServiceName.MORTGAGE_ACCOUNT_SERVICE.identifier())) {
            LOG.error("RestClientException : ServiceName: {} , ErrorDescription: {} ",
                    ServiceName.MORTGAGE_ACCOUNT_SERVICE.identifier(), errorResponse.getDescription());
            throw new CoreServiceException(ServiceName.MORTGAGE_ACCOUNT_SERVICE, errorType,
                    errorResponse.getDescription());
        }
        throw new CoreServiceException(serviceName, errorType, errorResponse.getDescription());
    }

    public void handleRestClientException(RestClientException restClientException, ServiceName serviceName,
                                          ErrorType errorType) throws CoreServiceException {
        if (restClientException instanceof ResourceAccessException) {
            LOG.error("1 RestClientException - ResourceAccessException : {} ",
                    restClientException.getLocalizedMessage());
            throw new ServiceCallFailureException(serviceName, errorType, restClientException.getMessage());
        }

        if (restClientException instanceof RestClientResponseException) {
            LOG.error("2 RestClientException - RestClientResponseException : {} ",
                    restClientException.getLocalizedMessage());
            handleRestClientResponseException((RestClientResponseException) restClientException, serviceName,
                    errorType);
        }
    }

}
