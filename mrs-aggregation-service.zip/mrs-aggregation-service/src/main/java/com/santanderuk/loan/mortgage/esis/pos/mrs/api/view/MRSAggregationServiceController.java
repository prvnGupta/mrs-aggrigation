/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs.api.view;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.EMPTY_STRING;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.InfoConstants.GASS_COMPLETE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.InfoConstants.INVOKING_GASS_SERVICE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.MRSAggregationService;
import com.santanderuk.loan.mortgage.esis.pos.mrs.gass.GenerateESISGassNotification;

import io.swagger.annotations.ApiOperation;

/**
 * Created by C0251500 on 13/09/2017 Description :
 */
@RestController
public class MRSAggregationServiceController {

	private static final Logger LOG = LoggerFactory.getLogger(MRSAggregationServiceController.class);

	@Autowired
	private MRSAggregationService mrsAggregationService;

	@Autowired
	private GenerateESISGassNotification generateESISGassNotification;

	@SuppressWarnings("UnusedDeclaration")
	@RequestMapping(path = "/posdocuments", method = RequestMethod.POST, consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<Response> populateEsisDocument(@RequestBody KFIRequest posRequest)
			throws CoreServiceException {
		LOG.info(INVOKING_GASS_SERVICE);
		generateESISGassNotification.populateGenerateKFIEventData(posRequest, posRequest.getAccount().getReference());
		LOG.info(GASS_COMPLETE);

		LOG.info("Start - Invoking MRS Service");
		Object esisCoreResponse = mrsAggregationService.generateEsisDocument(posRequest);
		LOG.debug("Done - Invoking MRS Service : ESIS document generated, now calling GMC to generate PDF template");
    Response mrsResponse = mrsAggregationService.generatePDF(esisCoreResponse);

		LOG.info("Done - PDF template generated - Now, Ingesting document into Nuxeo-Vault");
		mrsAggregationService.ingestDocument(posRequest, mrsResponse);
		LOG.info("Done - ESIS document ingested into Nuxeo-Vault- ESIS Reference ID - {}",
				mrsResponse.getKFIData().getKFIId());

		/* Removing PDF from response */
		Response.Output out = mrsResponse.getOutput();
		out.setValue(EMPTY_STRING);
		mrsResponse.setOutput(out);

		return new ResponseEntity<>(mrsResponse, HttpStatus.CREATED);
	}

	@ApiOperation(value = "Endpoint to retrieve KFI as PDF for given Kfi Id")
	@SuppressWarnings("UnusedDeclaration")
	@RequestMapping(path = "/document/{esis_id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<Response> retrieveKfiId(@PathVariable(name = "esis_id") String esis_id)
			throws CoreServiceException {
		LOG.info(INVOKING_GASS_SERVICE);
		generateESISGassNotification.populateRequestKFIEventData(esis_id);
		LOG.info(GASS_COMPLETE);

		LOG.info("Start - Calling to retrieve unique KFI/ESIS ID : {}", esis_id.replaceAll("[\r\n]", ""));
		Response response = mrsAggregationService.retrieveEsisAsPdf(esis_id);
		LOG.info("Done - Calling to retrieve unique KFI/ESIS ID : {}", esis_id.replaceAll("[\r\n]", ""));

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping(path = "/healthz", produces = MediaType.TEXT_PLAIN_VALUE)
	public String pingMe() {
		return "UP";
	}
}
