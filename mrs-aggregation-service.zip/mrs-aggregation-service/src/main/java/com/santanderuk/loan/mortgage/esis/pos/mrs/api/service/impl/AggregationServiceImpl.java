package com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.impl;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.MRSAggregationService;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.client.EsisCoreEngineClient;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.client.GmcClient;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.client.VaultClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by C0251500 on 14/11/2017
 * Description :
 */
@Service
public class AggregationServiceImpl implements MRSAggregationService {

    @Autowired
    private EsisCoreEngineClient esisCoreEngineClient;

    @Autowired
    private GmcClient gmcClient;

    @Autowired
    private VaultClient vaultClient;

    private static final Logger LOG = LoggerFactory.getLogger(AggregationServiceImpl.class);

    @Override
    public Object generateEsisDocument(KFIRequest kfiRequest) throws CoreServiceException {
        return esisCoreEngineClient.generateESIS(kfiRequest);
    }

    @Override
    public Response generatePDF(Object request) throws CoreServiceException {
        return gmcClient.generateTemplateAsPDF(request);
    }

    @Override
    public Boolean ingestDocument(KFIRequest request, Response gmcResponse) throws CoreServiceException {
        return vaultClient.ingestDocumentToVault(request, gmcResponse);
    }

    @Override
    public Response retrieveEsisAsPdf(String kfiId) throws CoreServiceException {
        return vaultClient.retrieveVaultDocument(kfiId);
    }
}
