package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_VAULT_API;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_VAULT_API_INGESTION;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName.VAULT_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.EMPTY_STRING;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.X_IBM_CLIENT_ID;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_CORE_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_VAULT_RETRIEVAL;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.Document;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.VaultIngestBean;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.VaultIngestResponseBean;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.VaultRetrieveBean;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.VaultRetrieveResponseBean;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception.CoreServiceErrorHandler;

/**
 * Created by C0251500 on 18/05/2018 Description :
 */
@Component
public class VaultClient extends BaseClient {

	private static final Logger LOG = LoggerFactory.getLogger(VaultClient.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private AppProps appProps;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private CoreServiceErrorHandler coreServiceErrorHandler;

	@Autowired
	private EsisCoreEngineClient esisCoreEngineClient;

	private String vaultDocumentServiceCreateURI;
	private String vaultDocumentServiceRetrieveURI;
	private String vaultDocumentServiceSearchURI;
	private String vaultDocumentServiceClientId;

	public Response retrieveVaultDocument(String kfiId) throws CoreServiceException {
		LOG.info("Start - retrieveVaultDocument... for Reference ID: {}", kfiId);
		String vaultResponse = EMPTY_STRING;
		Response response = null;

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(X_IBM_CLIENT_ID, vaultDocumentServiceClientId);
			HttpEntity<Object> entity = new HttpEntity<>(populateVaultRetrieveBean(kfiId), headers);

			LOG.debug("Start - retrieval service call");
			ResponseEntity<VaultRetrieveResponseBean> jsonResponse = restTemplate
					.postForEntity(vaultDocumentServiceRetrieveURI, entity, VaultRetrieveResponseBean.class);
      VaultRetrieveResponseBean vaultRetrieveResponseBean  = jsonResponse.getBody();
			if (null == vaultRetrieveResponseBean) {
				LOG.debug("Vault service call - COMPLETED with NO RESPONSE - Reference : {}", kfiId);
				throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, ERR_VAULT_RETRIEVAL);
			}
			LOG.debug("Done - retrieval service call");

			if (jsonResponse.getStatusCode().is2xxSuccessful()) {
				LOG.info("ESIS Document retrieved Successfully - Reference: {} ", kfiId);
				vaultResponse = vaultRetrieveResponseBean.getBinaries();
				response = populateResponseBean(kfiId, vaultResponse);
			} else if (jsonResponse.getStatusCode().is3xxRedirection()) {
				LOG.error("Vault-Nuxeo Service call - error : Multiple document retrieved for ESIS reference - {}",
						kfiId);
				throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, ERR_VAULT_RETRIEVAL);
			}
		} catch (RestClientException restClientException) {
			if (restClientException instanceof RestClientResponseException) {
				LOG.error("Vault-Nuxeo : Rest Client Exception : ", restClientException);
				if (((RestClientResponseException) restClientException).getRawStatusCode() == HttpStatus.NOT_FOUND
						.value()) {
					LOG.info("ESIS Document not found in Vault-Nuxeo - Reference : {} ", kfiId);
					LOG.info("Start - Invoking Kfi engine Api retrieval service");
					response = esisCoreEngineClient.retrieveKfiAsPdf(kfiId);
					LOG.info("Done - Invoking Kfi engine Api retrieval service: Document found with reference: {}",
							kfiId);
				} else {
					LOG.error("-- RESTClient error: Vault-Nuxeo service issue while retrieving : ESIS reference - {}",
							kfiId);
					coreServiceErrorHandler.handleRestClientException(restClientException, VAULT_SERVICE,
							ERROR_VAULT_API);
				}
			} else {
				LOG.error("** RESTClient error: Vault-Nuxeo service issue while retrieving : ESIS reference - {}",
						kfiId);
				LOG.error("** Vault-Nuxeo : Rest Client Exception : StackTrace:= ", restClientException);
				coreServiceErrorHandler.handleRestClientException(restClientException, VAULT_SERVICE, ERROR_VAULT_API);
			}
		}
		LOG.info("Done - retrieveVaultDocument... for Reference ID: {}", kfiId);
		return response;
	}

	public Boolean ingestDocumentToVault(KFIRequest request, Response response) throws CoreServiceException {
		LOG.info("Start - ingestDocumentToVault... ESIS reference: {}", response.getKFIData().getKFIId());
		String esisReference = EMPTY_STRING;
		try {
			esisReference = response.getKFIData().getKFIId();
			String accountNumber = EMPTY_STRING;
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(X_IBM_CLIENT_ID, vaultDocumentServiceClientId);

			if (request != null && request.getAccount() != null) {
				accountNumber = request.getAccount().getReference();
			}
			HttpEntity<Object> entity = new HttpEntity<>(populateVaultIngestBean(accountNumber, response),
					headers);
			LOG.debug("Start - Ingesting into Vault call");
			restTemplate.postForEntity(vaultDocumentServiceCreateURI, entity, VaultIngestResponseBean.class);
			LOG.debug("Done - Ingesting into Vault for ESIS reference : {}", esisReference);

		} catch (RestClientException restClientException) {
			LOG.error("RESTClient error: VAULT service INGEST document failed for ESIS reference : {}", esisReference);
			coreServiceErrorHandler.handleRestClientException(restClientException, VAULT_SERVICE,
					ERROR_VAULT_API_INGESTION);
		}

		LOG.info("Done - ingestDocumentToVault... ESIS reference: {}", response.getKFIData().getKFIId());
		return Boolean.TRUE;
	}

	private String populateVaultRetrieveBean(String kfiId) throws CoreServiceException {
		LOG.debug("Start - populateVaultRetrieveBean...");
		VaultRetrieveBean retrieveBean = new VaultRetrieveBean();
		retrieveBean.setUid(kfiId);
		try {
			String resp =  objectMapper.writeValueAsString(retrieveBean);
      LOG.debug("Start - populateVaultRetrieveBean...");
      return resp;
		} catch (JsonProcessingException e) {
			LOG.error("JsonProcessingException: StackTrace: ", e);
			throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, ERR_VAULT_RETRIEVAL);
		}

	}

	private String populateVaultIngestBean(String accountNumber, Response gmcResponse) throws CoreServiceException {
		LOG.debug("Start - populateVaultIngestBean...");
		String vaultRequest = EMPTY_STRING;
		VaultIngestBean ingestBean = new VaultIngestBean();
		ingestBean.setFile(gmcResponse.getOutput().getValue());
		ingestBean.setFileType("application/pdf");
		ingestBean.setName(gmcResponse.getKFIData().getKFIId());
		ingestBean.setInCustomerFacing(true); // ESIS documents always go into Customer folder.

		Document document = new Document();
		com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.Properties properties = new com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.Properties();
		properties.setDocStandardReference(gmcResponse.getKFIData().getKFIId());
		properties.setDocAccountNumber(accountNumber);
		properties.setDocSortCode(EMPTY_STRING);
		properties.setDocEntity("RETAIL");
		properties.setDocProductSubType("300");
		properties.setDocProductType(EMPTY_STRING);
		properties.setDocCompanyCode("0015");
		properties.setDocCommunicationType("2435");
		properties.setDocInternalAccountNumber(EMPTY_STRING);
		properties.setDocBrand("Retail");
		properties.setDcDescription("Santander Mortgage ESIS");
		properties.setDocApplicationGroup("EDOC");
		properties.setDocApplicationName("ESIS");
		properties.setDocPriority("3");
		document.setProperties(properties);
		ingestBean.setDocument(document);

		try {
			vaultRequest = objectMapper.writeValueAsString(ingestBean);
			LOG.debug("Vault Ingest Request : {}", vaultRequest);
		} catch (JsonProcessingException exception) {
			exception.printStackTrace();
			throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, ERR_CORE_SERVICE);
		}
		LOG.debug("Done - populateVaultIngestBean...");
		return vaultRequest;
	}

	@PostConstruct
	private void constructResourceUri() {
		vaultDocumentServiceClientId = appProps.getVaultDocumentServiceClientId();
		vaultDocumentServiceCreateURI = appProps.getVaultDocumentServiceCreateURI();
		vaultDocumentServiceRetrieveURI = appProps.getVaultDocumentServiceRetrieveURI();
		vaultDocumentServiceSearchURI = appProps.getVaultDocumentServiceSearchURI();

		LOG.debug("URL: vaultDocumentServiceCreateURI: {}", vaultDocumentServiceCreateURI);
		LOG.debug("URL: vaultDocumentServiceRetrieveURI: {}", vaultDocumentServiceRetrieveURI);
		LOG.debug("URL: vaultDocumentServiceSearchURI: {}", vaultDocumentServiceSearchURI);
	}
}
