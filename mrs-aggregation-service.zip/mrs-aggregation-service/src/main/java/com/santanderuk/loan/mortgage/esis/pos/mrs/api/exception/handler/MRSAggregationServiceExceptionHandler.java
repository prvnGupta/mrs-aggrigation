/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.handler;

import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorMap;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorResponse;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception.ServiceCallFailureException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Date;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.SYSTEM_ERROR;


/**
 * Created by C0251500 on 15/11/2017
 * Description :
 */

@ControllerAdvice
@SuppressWarnings("unused")
public class MRSAggregationServiceExceptionHandler
{
    private static final Logger LOG = LoggerFactory.getLogger(MRSAggregationServiceExceptionHandler.class);

    @Autowired
    private ErrorMap errorMap;

    @ExceptionHandler(CoreServiceException.class)
    public ResponseEntity<ErrorResponse> handleCoreServiceException(CoreServiceException exception) {
        ErrorResponse errorResponse = logErrorResponse(exception.getServiceName(), exception.getErrorType(), exception.getMessage());
        LOG.error(errorResponse.toValues());
        return new ResponseEntity<ErrorResponse>(errorResponse, httpStatusFrom(exception.getErrorType()));
    }

    @ExceptionHandler(ServiceCallFailureException.class)
    public ResponseEntity<ErrorResponse> handleServiceCallFailureException(ServiceCallFailureException exception) {
        ErrorResponse errorResponse = logErrorResponse(exception.getServiceName(), exception.getErrorType(), exception.getMessage());
        LOG.error(errorResponse.toValues());
        return new ResponseEntity<ErrorResponse>(errorResponse, httpStatusFrom(exception.getErrorType()));
    }

    private ErrorResponse populateErrorResponse(ServiceName serviceName, ErrorType errorType, String moreInformation) {
        return new ErrorResponse(serviceName.identifier(), new Date(), errorMap.getMessage(errorType), moreInformation);
    }

    private ErrorResponse withErrorMessage(String message, String description) {
        return new ErrorResponse(message, null, description, null);
    }

    private HttpStatus httpStatusFrom(ErrorType errorMessageType) {
        return errorMessageType == SYSTEM_ERROR  ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.BAD_REQUEST;
    }

    private ErrorResponse logErrorResponse(ServiceName serviceName, ErrorType errorType, String message) {
        ErrorResponse errorResponse = populateErrorResponse(serviceName, errorType, message);
        return errorResponse;
    }

}
