package com.santanderuk.loan.mortgage.esis.pos.mrs.core.util;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_GMC_API;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName.GMC_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.QUOTATION_REFERENCE_NUMBER;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;

/**
 * Created by C0251500 on 21/03/2018 Description :
 */

public class UtilConverter {

	public static String compileJsonForGMC(String jsonString) throws CoreServiceException {
		JsonNode jsonNode = null;
		ObjectMapper objectMapper = new ObjectMapper();
		String jsonResponse = null;
		try {
			jsonNode = objectMapper.readValue(jsonString, JsonNode.class);
			Iterator<Map.Entry<String, JsonNode>> userEntries = jsonNode.fields();
			while (userEntries.hasNext()) {
				Map.Entry<String, JsonNode> userEntry = userEntries.next();
				jsonResponse = userEntry.getValue().asText();
			}
		} catch (IOException e) {
			throw new CoreServiceException(GMC_SERVICE, ERROR_GMC_API, "Cannot parse json response");
		}
		return jsonResponse;
	}

	public static String compileJsonForKFIReference(String jsonString) throws CoreServiceException {
		JsonNode jsonNode = null;
		ObjectMapper objectMapper = new ObjectMapper();
		String jsonResponse = null;
		try {
			jsonNode = objectMapper.readValue(jsonString, JsonNode.class);
			Iterator<Map.Entry<String, JsonNode>> userEntries = jsonNode.fields();
			while (userEntries.hasNext()) {
				Map.Entry<String, JsonNode> userEntry = userEntries.next();
				JsonNode node = userEntry.getValue().get(QUOTATION_REFERENCE_NUMBER);
				if (null != node) {
					jsonResponse = node.asText();
					break;
				}

			}
		} catch (IOException e) {
			throw new CoreServiceException(GMC_SERVICE, ERROR_GMC_API, "Cannot parse json response");
		}
		return jsonResponse;
	}
}
