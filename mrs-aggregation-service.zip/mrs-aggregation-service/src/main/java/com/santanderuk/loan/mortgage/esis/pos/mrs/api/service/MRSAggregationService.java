package com.santanderuk.loan.mortgage.esis.pos.mrs.api.service;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;

/**
 * Created by C0251500 on 14/11/2017
 * Description :
 */
public interface MRSAggregationService {


    public Object generateEsisDocument(KFIRequest kfiRequest) throws CoreServiceException;

    public Response generatePDF(Object gmcRequest) throws CoreServiceException;

    public Boolean ingestDocument(KFIRequest request, Response gmcResponse) throws CoreServiceException;

    public Response retrieveEsisAsPdf(String kfiId) throws CoreServiceException;


}
