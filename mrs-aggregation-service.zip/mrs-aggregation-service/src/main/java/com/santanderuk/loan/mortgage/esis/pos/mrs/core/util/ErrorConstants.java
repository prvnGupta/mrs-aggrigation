/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs.core.util;

/**
 * Created by C0251500 on 15/12/2017
 * Description :
 */
public class ErrorConstants {

    public static final String DOCUMENT_GEN_FAILED = "Document Generation failed : ";
    public static final String ERR_CONTENT_MISSING = "Request could not be processed as some required fields not present. Please verify and re-submit the application.";
    public static final String ERR_BASIC_VALIDATION = "Your request could not be processed as some required fields were left blank.  Please re-submit your request.";
    public static final String ERR_SYSTEM_ERROR = "Your request could not be processed.  Please try again.  If the problem persists, please contact Santander technical support.";
    public static final String ERR_INVALID_DATA = "Request could not be processed as incorrect data in the request. Please verify and re-submit the application.";
    public static final String ERR_NO_KFI_REFERENCE = "Request could not be processed, KFI reference ID not provided. Please verify and re-submit the application.";
    public static final String ERR_Vault_MULTIPLE_DOCUMENT = "Multiple document found in Vault for given reference";
    ;
    public static final String ERR_EMPTY_ESIS_CORE_RESPONSE = "Invalid/Empty response from ESIS Core service";
    public static final String ERR_MRS_SERVICE_EXCEPTION = "MRS_SERVICE_EXCEPTION caught";
    public static final String LABEL_ERROR_HANDLER = "MRS_SERVICE_ERROR_HANDLER";
    private static String DOCUMENT_FAIL = "There has been an error in processing the document, this means the application cannot proceed, " +
            "please take a note of the error code, date and time and raise an incident with the help desk.";
    public static final String ERR_CORE_SERVICE = DOCUMENT_GEN_FAILED + DOCUMENT_FAIL;
    public static final String ERR_CORE_SERVICE_RETRIEVAL = "Document Retrieval failed : " + DOCUMENT_FAIL;
    public static final String ERR_CORE_SERVICE_UNZIP = DOCUMENT_GEN_FAILED + DOCUMENT_FAIL;
    public static final String ERR_VAULT_RETRIEVAL = "Document Retrieval failed: ESIS document not found : " + DOCUMENT_FAIL;
    public static final String ERR_CORE_RESPONSE_BAD_FORMAT = DOCUMENT_GEN_FAILED + DOCUMENT_FAIL;
    public static final String ERR_GMC = DOCUMENT_GEN_FAILED + DOCUMENT_FAIL;
    public static final String ERR_VAULT = "Document Retrieval failed : " + DOCUMENT_FAIL;
    public static final String ERR_VAULT_INGESTION = DOCUMENT_GEN_FAILED + DOCUMENT_FAIL;
    public static final String ERR_GMC_BAD_RESPONSE = DOCUMENT_GEN_FAILED + DOCUMENT_FAIL;
    public static final String ERR_Vault_BAD_RESPONSE = DOCUMENT_GEN_FAILED + DOCUMENT_FAIL;


}
