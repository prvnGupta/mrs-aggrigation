package com.santanderuk.loan.mortgage.esis.pos.mrs.gass;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.CDATA_END;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.CDATA_START;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.EMPTY_STRING;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.GENERATE_ESIS;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.REQUEST_ESIS;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.mortgage.integration.gass.client.GassClient;

@Component
public class GenerateESISGassNotification {

	private static final Logger LOG = LoggerFactory.getLogger(GenerateESISGassNotification.class.getSimpleName());
    private static final JAXBContext context;
    static {
        try {
            context = JAXBContext.newInstance(KFIRequest.class);
        } catch (JAXBException error) {
            LOG.error("JAXBException : ", error);
            throw new RuntimeException(error);
        }
    }

	@Autowired
	private GassClient gassClient;

	@Autowired
	private AppProps appProps;

	public void populateGenerateKFIEventData(KFIRequest posRequest, String accountNumber) {
		try {
			AuditEventDataGenerate auditEventDataGenerate = new AuditEventDataGenerate();

			StringWriter sw = new StringWriter();
			Marshaller jaxbMarshaller = context.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			jaxbMarshaller.marshal(posRequest, sw);

			if (posRequest != null) {
				auditEventDataGenerate.setFrmtdData(CDATA_START.concat(sw.toString().concat(CDATA_END)));
			} else {
				auditEventDataGenerate.setFrmtdData(EMPTY_STRING);
				LOG.error("COULD NOT GET FRMTDDATA");
			}
			auditEventDataGenerate.setAppSysId(appProps.getAppSysId());
			auditEventDataGenerate.setTrnGrpId(appProps.getTrnGrpId());
			auditEventDataGenerate.setTrnTpName(GENERATE_ESIS);
			auditEventDataGenerate.setOprTnSucTyp(appProps.getOprTnSucTyp());
			if (!StringUtils.isEmpty(accountNumber)) {
				auditEventDataGenerate.setKeyHldgRef(accountNumber);
			} else {
				auditEventDataGenerate.setKeyHldgRef(EMPTY_STRING);
				LOG.error("GASS ERROR: COULD NOT GET KEYHLDGREF");
			}
			auditEventDataGenerate.setOrgId(appProps.getOrgId());
			auditEventDataGenerate.setOrgUtTp(appProps.getOrgUtTp());
			auditEventDataGenerate.setDvcTyp(appProps.getDvcTyp());
			if (appProps.getUsrId() != null) {
				auditEventDataGenerate.setUsrId(appProps.getUsrId());
			} else {
				auditEventDataGenerate.setUsrId(EMPTY_STRING);
				LOG.error("GASS ERROR: COULD NOT GET USERID");
			}
			auditEventDataGenerate.setCompSysId(appProps.getCompSysId());

			if (gassClient != null) {
				LOG.info("Posting GASS notification");
				gassClient.postNotification(auditEventDataGenerate);
			} else {
				LOG.error("GassClient is not set properly");
			}
		} catch (Exception e) {
			LOG.error("GASS error :  StackTrace : ", e);
		}

	}

	public void populateRequestKFIEventData(String esis_id) {
		try {
			AuditEventDataRetrieve auditEventDataRetrieve = new AuditEventDataRetrieve();
			if (esis_id != null) {
				auditEventDataRetrieve.setFrmtdData(esis_id);
			} else {
				auditEventDataRetrieve.setFrmtdData(EMPTY_STRING);
				LOG.error("COULD NOT GET FRMTDDATA");
			}
			auditEventDataRetrieve.setAppSysId(appProps.getAppSysId());
			auditEventDataRetrieve.setTrnGrpId(appProps.getTrnGrpId());
			auditEventDataRetrieve.setTrnTpName(REQUEST_ESIS);
			auditEventDataRetrieve.setOprTnSucTyp(appProps.getOprTnSucTyp());
			auditEventDataRetrieve.setOrgId(appProps.getOrgId());
			auditEventDataRetrieve.setOrgUtTp(appProps.getOrgUtTp());
			auditEventDataRetrieve.setDvcTyp(appProps.getDvcTyp());
			if (appProps.getUsrId() != null) {
				auditEventDataRetrieve.setUsrId(appProps.getUsrId());
			} else {
				auditEventDataRetrieve.setUsrId(EMPTY_STRING);
				LOG.error("COULD NOT GET USERID");
			}
			auditEventDataRetrieve.setCompSysId(appProps.getCompSysId());

			if (gassClient != null) {
				LOG.info("Posting GASS message");
				gassClient.postNotification(auditEventDataRetrieve);
			} else {
				LOG.error("GassClient is not set properly");
			}
		} catch (Exception e) {
			LOG.error("GASS_EXCEPTION : StackTrace := ", e);
		}
	}
}
