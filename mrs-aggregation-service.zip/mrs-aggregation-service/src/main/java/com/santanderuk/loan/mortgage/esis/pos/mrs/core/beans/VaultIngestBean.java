package com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by C0251500 on 04/06/2018
 * Description :
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "fileType",
        "name",
        "inCustomerFacing",
        "file",
        "document"
})
public class VaultIngestBean
{
    @JsonProperty("fileType")
    private String fileType;
    @JsonProperty("name")
    private String name;
    @JsonProperty("inCustomerFacing")
    private boolean inCustomerFacing;
    @JsonProperty("file")
    private String file;
    @JsonProperty("document")
    private Document document;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("fileType")
    public String getFileType() {
        return fileType;
    }

    @JsonProperty("fileType")
    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    public boolean isInCustomerFacing() {
        return inCustomerFacing;
    }

    public void setInCustomerFacing(boolean inCustomerFacing) {
        this.inCustomerFacing = inCustomerFacing;
    }

    @JsonProperty("file")
    public String getFile() {
        return file;
    }

    @JsonProperty("file")
    public void setFile(String file) {
        this.file = file;
    }

    @JsonProperty("document")
    public Document getDocument() {
        return document;
    }

    @JsonProperty("document")
    public void setDocument(Document document) {
        this.document = document;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
