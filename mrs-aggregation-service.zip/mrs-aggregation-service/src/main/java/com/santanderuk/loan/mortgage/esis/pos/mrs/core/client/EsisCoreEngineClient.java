package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_ESIS_CORE_ENGINE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_ESIS_CORE_ENGINE_RETRIEVAL;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_VAULT_API_RETRIEVAL;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName.ESIS_CORE_ENGINE_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName.VAULT_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.X_IBM_CLIENT_ID;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_CORE_SERVICE_UNZIP;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_EMPTY_ESIS_CORE_RESPONSE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_VAULT_RETRIEVAL;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.AbbeyYN;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.KFIResponse;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception.CoreServiceErrorHandler;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Base64Zipper;

/**
 * Created by C0251500 on 15/11/2017 Description :
 */
@Component
public class EsisCoreEngineClient {

	private static final Logger LOG = LoggerFactory.getLogger(EsisCoreEngineClient.class);

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private AppProps appProps;
	@Autowired
	private CoreServiceErrorHandler coreServiceErrorHandler;


	public Object generateESIS(KFIRequest kfiRequest) throws CoreServiceException {
		LOG.info("Start - generateESIS...");
		Object resp = null;
    try {
			HttpEntity<Object> entity = new HttpEntity<>(kfiRequest, httpHeaders(MediaType.APPLICATION_XML));
      ResponseEntity<Object> jsonResponse = restTemplate.postForEntity(appProps.getPosCoreServiceURI(), entity, Object.class);
      resp = jsonResponse.getBody();
      if (resp == null) {
        CoreServiceException coreServiceException = new CoreServiceException(ESIS_CORE_ENGINE_SERVICE,
          ERROR_ESIS_CORE_ENGINE, ERR_EMPTY_ESIS_CORE_RESPONSE);
        LOG.error("Error in MRS - ESIS core-engine call - ServiceName: {} , Message: {}",
          ESIS_CORE_ENGINE_SERVICE.identifier(), ERR_EMPTY_ESIS_CORE_RESPONSE);
        throw coreServiceException;
      }
		} catch (RestClientException restClientException) {
			LOG.error("RESTClient error: Generating ESIS - Reference : {} - Cause : {} ", kfiRequest.getKFIReference(),
					restClientException.getCause());
			LOG.error("RESTClient error: StackTrace : ", restClientException);
			coreServiceErrorHandler.handleRestClientException(restClientException, ESIS_CORE_ENGINE_SERVICE,
					ERROR_ESIS_CORE_ENGINE);
		}

		LOG.info("Done - generateESIS...");
		return resp;
	}

	public Response retrieveKfiAsPdf(String esisId) throws CoreServiceException {
		LOG.info("Start - retrieveKfiAsPdf... for Reference ID : {}", esisId);
		Response finalResponse = null;
		try {
      ResponseEntity<Response> response = restTemplate.exchange(appProps.getRetrieveKfiURI() + "/" + esisId,
					HttpMethod.GET,
					new HttpEntity<>(httpHeaders(MediaType.APPLICATION_JSON)),
					Response.class);
			if (response.getBody() != null) {
				LOG.debug("Response Code : {} ", response.getStatusCode());
				finalResponse = response.getBody();
				if (isEsisDocument(finalResponse)) {
					LOG.error("Document Retrieval failed: KFI engine can't retrieve ESIS document");
					throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API_RETRIEVAL, ERR_VAULT_RETRIEVAL);
				}
			}
		} catch (RestClientException restClientException) {
			LOG.error("RESTClient error: Retrieving ESIS - Reference : {}", esisId);
			LOG.error("RESTClient error: StackTrace : ", restClientException);
			coreServiceErrorHandler.handleRestClientException(restClientException, ESIS_CORE_ENGINE_SERVICE,
					ERROR_ESIS_CORE_ENGINE_RETRIEVAL);
		}
		LOG.info("Done - retrieveKfiAsPdf... for Reference ID : {}", esisId);
		return finalResponse;
	}

	private HttpHeaders httpHeaders(MediaType type) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(type);
		headers.set(X_IBM_CLIENT_ID, appProps.getCoreApiClientId());
		return headers;
	}

	private boolean isEsisDocument(Response finalResponse) throws CoreServiceException {
		LOG.debug("Start - isEsisDocument...");
		boolean isEsisDoc = false;
		if (finalResponse != null && finalResponse.getKFIData() != null) {
			String kfiData = finalResponse.getKFIData().getValue();
			byte[] zipData = Base64.decodeBase64(kfiData);
			String unzipData = Base64Zipper.unzip(zipData);
			StringReader reader = new StringReader(unzipData);

			try {
        JAXBContext jaxbContext = JAXBContext.newInstance(KFIResponse.class);
				Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				KFIResponse kfiResponse = (KFIResponse) unmarshaller.unmarshal(reader);

				if (kfiResponse != null && kfiResponse.getFlags() != null &&
             kfiResponse.getFlags().getESISDoc() == AbbeyYN.Y) {
						isEsisDoc = true;

				}
			} catch (JAXBException e) {
				CoreServiceException coreServiceException = new CoreServiceException(ESIS_CORE_ENGINE_SERVICE,
						ERROR_ESIS_CORE_ENGINE, ERR_CORE_SERVICE_UNZIP);
				LOG.error("JAXBException error: StackTrace : ", e);
				throw coreServiceException;
			}
		}
		LOG.debug("Done - isEsisDocument...flag :{}", isEsisDoc);
		return isEsisDoc;
	}

}
