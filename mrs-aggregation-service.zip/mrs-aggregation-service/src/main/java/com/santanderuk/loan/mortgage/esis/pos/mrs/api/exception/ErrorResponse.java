/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "errorResponse")
@XmlType(propOrder = { "error", "date", "description", "moreInformation" })
@XmlAccessorType(XmlAccessType.FIELD)
public class ErrorResponse {

	@XmlElement(name = "error", required = true)
	private String error;

	@XmlElement(name = "date", required = false)
	private Date date;

	@XmlElement(name = "description", required = true)
	private String description;

	@XmlElement(name = "moreInformation", required = false)
	private String moreInformation;

	public ErrorResponse() {
	}

	public ErrorResponse(String error, Date date, String description, String moreInformation) {
		this.error = error;
		this.date = (Date) date.clone();
		this.description = description;
		this.moreInformation = moreInformation;
	}

	public String getError() {
		return error;
	}

	public String getDescription() {
		return description;
	}

	public Date getDate() {
		return (Date) date.clone();
	}

	public String getMoreInformation() {
		return moreInformation;
	}

	public String toValues() {
		return "errorResponse{" + "error='" + error + '\'' + ", date=" + date + ", description='" + description + '\''
				+ ", moreInformation='" + moreInformation + '\'' + '}';
	}
}
