/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception;


import com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName;

public class CoreServiceException extends Exception {

    private ServiceName serviceName;
    private ErrorType errorType;

    public ServiceName getServiceName() {
        return serviceName;
    }

    public CoreServiceException(ServiceName serviceName, ErrorType errorType) {
        this.serviceName = serviceName;
        this.errorType = errorType;
    }

    public CoreServiceException(ServiceName serviceName, ErrorType errorType, String moreInformation) {
        super(moreInformation);
        this.serviceName = serviceName;
        this.errorType = errorType;
    }

    public CoreServiceException(ServiceName serviceName, ErrorType errorType, String message, Throwable cause) {
        super(message, cause);
        this.serviceName = serviceName;
        this.errorType = errorType;
    }

    public ErrorType getErrorType() {
        return errorType;
    }



}

