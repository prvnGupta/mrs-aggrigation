package com.santanderuk.loan.mortgage.esis.pos.mrs.core.exception;


import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.service.ServiceName;

public class ServiceCallFailureException extends CoreServiceException {

    public ServiceCallFailureException(ServiceName serviceName, ErrorType errorType, String message) {
        super(serviceName, errorType, message);
    }


}
