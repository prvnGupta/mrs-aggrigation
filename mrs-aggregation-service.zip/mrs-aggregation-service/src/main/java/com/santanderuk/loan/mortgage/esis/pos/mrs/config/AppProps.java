package com.santanderuk.loan.mortgage.esis.pos.mrs.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by C0251500 on 15/02/2018
 * Description :
 */
@Component
public class AppProps {
    @Value("${core-api.client-id}")
    private String coreApiClientId;

    @Value("${core-api.service.pos-core-service.uri}")
    private String posCoreServiceURI;
    @Value("${core-api.service.pos-core-service.retrieve-kfi-uri}")
    private String retrieveKfiURI;

    @Value("${core-api.service.gmc-core-service.uri-base64}")
    private String gmcCoreServiceURIBase64;
    @Value("${core-api.service.gmc-core-service.client-id}")
    private String gmcClientId;
    @Value("${core-api.service.gmc-core-service.document-code}")
    private String gmcDocumentCode;
    @Value("${core-api.service.gmc-core-service.template}")
    private String gmcTemplate;

    @Value("${core-api.service.vault-document-service.uri-ingest}")
    private String vaultDocumentServiceCreateURI;
    @Value("${core-api.service.vault-document-service.uri-retrieve}")
    private String vaultDocumentServiceRetrieveURI;
    @Value("${core-api.service.vault-document-service.uri-search}")
    private String vaultDocumentServiceSearchURI;
    @Value("${core-api.service.vault-document-service.client-id}")
    private String vaultDocumentServiceClientId;


    @Value("${rmq.host}")
    private String rmqHost;
    @Value("${rmq.port}")
    private int rmqPort;
    @Value("${rmq.username}")
    private String rmqUsername;
    @Value("${rmq.password}")
    private String rmqPassword;
    @Value("${rmq.queue}")
    private String rmqQueue;


    @Value("${gac.appSysId}")
    private int appSysId;
    @Value("${gac.trnGrpId}")
    private int trnGrpId;
    @Value("${gac.oprTnSucTyp}")
    private int oprTnSucTyp;
    @Value("${gac.orgId}")
    private int orgId;
    @Value("${gac.orgUtTp}")
    private int orgUtTp;
    @Value("${gac.dvcTyp}")
    private int dvcTyp;
    @Value("${gac.usrId}")
    private String usrId;
    @Value("${gac.compSysId}")
    private int compSysId;

    public String getCoreApiClientId() {
        return coreApiClientId;
    }

    public String getPosCoreServiceURI() {
        return posCoreServiceURI;
    }

    public String getGmcCoreServiceURIBase64() {
        return gmcCoreServiceURIBase64;
    }

    public String getGmcClientId() {
        return gmcClientId;
    }

    public String getGmcDocumentCode() {
        return gmcDocumentCode;
    }

    public String getGmcTemplate() {
        return gmcTemplate;
    }

    public String getRetrieveKfiURI() {
        return retrieveKfiURI;
    }

    public String getVaultDocumentServiceCreateURI() {
        return vaultDocumentServiceCreateURI;
    }

    public String getVaultDocumentServiceRetrieveURI() {
        return vaultDocumentServiceRetrieveURI;
    }

    public String getVaultDocumentServiceClientId() {
        return vaultDocumentServiceClientId;
    }

    public String getRmqHost() {
        return rmqHost;
    }

    public int getRmqPort() {
        return rmqPort;
    }

    public String getRmqUsername() {
        return rmqUsername;
    }

    public String getRmqPassword() {
        return rmqPassword;
    }

    public String getRmqQueue() { return rmqQueue;}

    public int getAppSysId() {
        return appSysId;
    }

    public int getTrnGrpId() {
        return trnGrpId;
    }

    public int getOrgId() {
        return orgId;
    }

    public int getOrgUtTp() {
        return orgUtTp;
    }

    public String getVaultDocumentServiceSearchURI() {
        return vaultDocumentServiceSearchURI;
    }

    public int getDvcTyp() {
        return dvcTyp;
    }

    public int getCompSysId() {
        return compSysId;
    }

    public String getUsrId() {
        return usrId;
    }

    public int getOprTnSucTyp() {
        return oprTnSucTyp;
    }
}

