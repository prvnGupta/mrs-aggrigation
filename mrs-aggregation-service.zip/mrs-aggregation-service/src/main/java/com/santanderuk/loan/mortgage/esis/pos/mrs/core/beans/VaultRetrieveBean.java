package com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans;

/**
 * Created by C0251500 on 05/06/2018
 * Description :
 */
public class VaultRetrieveBean {

    private String uid;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
