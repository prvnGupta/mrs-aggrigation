package com.santanderuk.loan.mortgage.esis.pos.mrs.core.util;

public class InfoConstants {
    public static final String INVOKING_GASS_SERVICE = "Start - Invoking Gas Service";
    public static final String GASS_COMPLETE = "Done - Invoking GASS Service";
}
