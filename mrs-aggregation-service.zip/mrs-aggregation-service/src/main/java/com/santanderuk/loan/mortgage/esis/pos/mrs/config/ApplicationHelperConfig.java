package com.santanderuk.loan.mortgage.esis.pos.mrs.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ApplicationHelperConfig {

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    public ErrorMap errorMap() {
        return ErrorMap.buildErrorResponseMessageMap();
    }

    @Bean
    public ObjectMapper customeObjectMapper(){
        return new ObjectMapper();
    }


}
