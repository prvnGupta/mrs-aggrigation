package com.santanderuk.loan.mortgage.esis.pos.mrs.gass;

import com.santanderuk.mortgage.integration.gass.client.annotations.*;

public class AuditEventDataGenerate {

    @AuditRecordWhat(field = AuditRecordWhat.Field.FRMTDDATA)
    private String frmtdData;

    @AuditRecordWhere(field = AuditRecordWhere.Field.APPSYSID)
    private int appSysId;

    @AuditRecordTrn(field = AuditRecordTrn.Field.AUDITTRNGRPID)
    private int trnGrpId;

    @AuditRecordTrn(field = AuditRecordTrn.Field.AUDITTRNTPNAME)
    private String trnTpName;

    @AuditRecordLogKey(field = AuditRecordLogKey.Field.OPRTNSUCTYP)
    private int oprTnSucTyp;

    @AuditRecordLogKey(field = AuditRecordLogKey.Field.KEYHLDGREF)
    private String keyHldgRef;

    @AuditRecordWhere(field = AuditRecordWhere.Field.ORGID)
    private int orgId;

    @AuditRecordWhere(field = AuditRecordWhere.Field.ORGUTTP)
    private int orgUtTp;

    @AuditRecordWhere(field = AuditRecordWhere.Field.DVCTYP)
    private int dvcTyp;

    @AuditRecordWho(field = AuditRecordWho.Field.USRID, group = AuditRecordWho.Group.AUDITRECINSTGRUSER)
    private String usrId;

    @AuditRecordWho(field = AuditRecordWho.Field.COMPSYSID, group = AuditRecordWho.Group.AUDITRECINSTGRUSER)
    private int compSysId;

    public int getAppSysId() {
        return appSysId;
    }

    public void setAppSysId(int appSysId) {
        this.appSysId = appSysId;
    }

    public int getTrnGrpId() {
        return trnGrpId;
    }

    public void setTrnGrpId(int trnGrpId) {
        this.trnGrpId = trnGrpId;
    }

    public String getTrnTpName() {
        return trnTpName;
    }

    public void setTrnTpName(String trnTpName) {
        this.trnTpName = trnTpName;
    }

    public String getKeyHldgRef() {
        return keyHldgRef;
    }

    public void setKeyHldgRef(String keyHldgRef) {
        this.keyHldgRef = keyHldgRef;
    }

    public int getOrgId() {
        return orgId;
    }

    public void setOrgId(int orgId) {
        this.orgId = orgId;
    }

    public int getOrgUtTp() {
        return orgUtTp;
    }

    public void setOrgUtTp(int orgUtTp) {
        this.orgUtTp = orgUtTp;
    }

    public int getDvcTyp() {
        return dvcTyp;
    }

    public void setDvcTyp(int dvcTyp) {
        this.dvcTyp = dvcTyp;
    }

    public String getFrmtdData() {
        return frmtdData;
    }

    public void setFrmtdData(String frmtdData) {
        this.frmtdData = frmtdData;
    }

    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    public int getCompSysId() {
        return compSysId;
    }

    public void setCompSysId(int compSysId) {
        this.compSysId = compSysId;
    }

    public int getOprTnSucTyp() {
        return oprTnSucTyp;
    }

    public void setOprTnSucTyp(int oprTnSucTyp) {
        this.oprTnSucTyp = oprTnSucTyp;
    }
}
