package com.santanderuk.loan.mortgage.esis.pos.mrs.config;

import com.santanderuk.mortgage.integration.gass.client.config.RabbitMqClientConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GassConfig {

    @Autowired
    private AppProps appProps;

    @Bean
    public RabbitMqClientConfig rabbitMqClientConfig(){
        return new RabbitMqClientConfig()
                .withHost(appProps.getRmqHost())
                .withPort(appProps.getRmqPort())
                .withUsername(appProps.getRmqUsername())
                .withPassword(appProps.getRmqPassword())
                .withQueue(appProps.getRmqQueue());
    }

}
