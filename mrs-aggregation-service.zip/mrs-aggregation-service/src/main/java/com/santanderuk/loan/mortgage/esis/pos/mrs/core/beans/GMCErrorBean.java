package com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans;

/**
 * Created by C0251500 on 13/03/2018
 * Description :
 */
public class GMCErrorBean {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "GMCErrorBean{" +
                "message='" + message + '\'' +
                '}';
    }
}
