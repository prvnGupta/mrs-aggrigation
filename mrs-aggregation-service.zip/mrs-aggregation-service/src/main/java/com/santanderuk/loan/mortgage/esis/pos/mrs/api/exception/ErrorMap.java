/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception;

import java.util.EnumMap;
import java.util.Map;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.*;

public class ErrorMap {
    private Map<ErrorType, String> messages = new EnumMap<ErrorType, String>(ErrorType.class);

    public String getMessage(ErrorType key) {
        return messages.get(key);
    }

    public static ErrorMap buildErrorResponseMessageMap() {
        ErrorMap errorMap = new ErrorMap();
        errorMap.messages.put(ErrorType.ERROR_BASIC_VALIDATION, ERR_BASIC_VALIDATION);
        errorMap.messages.put(ErrorType.SYSTEM_ERROR, ERR_SYSTEM_ERROR);
        errorMap.messages.put(ErrorType.ERROR_ESIS_CORE_ENGINE, ERR_CORE_SERVICE);
        errorMap.messages.put(ErrorType.ERROR_ESIS_CORE_ENGINE_RETRIEVAL, ERR_CORE_SERVICE_RETRIEVAL);
        errorMap.messages.put(ErrorType.ERROR_CONTENT_MISSING, ERR_CONTENT_MISSING);
        errorMap.messages.put(ErrorType.ERROR_INVALID_DATA, ERR_INVALID_DATA);
        errorMap.messages.put(ErrorType.ERROR_GMC_API, ERR_GMC);
        errorMap.messages.put(ErrorType.ERROR_VAULT_API, ERR_VAULT);
        errorMap.messages.put(ErrorType.ERROR_VAULT_API_INGESTION, ERR_VAULT_INGESTION);
        errorMap.messages.put(ErrorType.ERROR_VAULT_API_RETRIEVAL, ERR_VAULT_RETRIEVAL);
        return errorMap;
    }
}
